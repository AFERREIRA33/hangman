package main

import (
	"piscine"
	"fmt"
)
func main() {
	fmt.Println(piscine.RandomWord())
}